package com.example.marvel_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarvelApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
